# Sample creator 

Implementation package of the "On the Creation of Representative Samples of Software Repositories" paper (under review). 
The running example is showcased in the Zenodo repository.